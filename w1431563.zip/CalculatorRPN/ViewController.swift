//
//  ViewController.swift
//  CalculatorRPN
//
//  Created by dharm on 07/02/2017.
//  Copyright © 2017 dharm. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var decimal: UIButton!
    @IBOutlet weak var calcDisplay: UILabel!
    @IBOutlet weak var sgARC: UISegmentedControl!
    @IBOutlet weak var sin: UIButton!
    @IBOutlet weak var cos: UIButton!
    @IBOutlet weak var tan: UIButton!
    @IBOutlet weak var labelDisplay: UILabel!
    var calcEngine :CalculatorEngine?
    var previousData:String? = nil
    
    
    
    @IBOutlet weak var updatelabel: UILabel!
    var updadeLabel = true
    
    var newStr = ""
    var displayStr = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if self.calcEngine == nil {
            
            self.calcEngine = CalculatorEngine()
        }
        //if statement that loads up previous data after the app is closed
        previousData = UserDefaults.standard.string(forKey: "calcDisplay")
        if previousData != nil {
            newStr = previousData!
        }
    }
    
    override  var prefersStatusBarHidden: Bool {
        return true
    }
    
    //boolen: overwirtes the zero when digits are entered
    var userHasStaredTyping = false
    
    @IBAction func digitPressed(_ sender: UIButton) {
        // when user pressa digit it will appear on the labelDisplay
        let digit = sender.currentTitle!
        print("digit pressed = \(digit)")
        if userHasStaredTyping {
            labelDisplay.text = labelDisplay.text! + "\(digit)"
        }
        else {
            labelDisplay.text = digit
            userHasStaredTyping = true
        }
    }
    
    var displayValue : Double {
        
        get
        {
            let test:Double
            //
            if (labelDisplay.text == "Error"){
                test = 0.0
            }else{
                test = (NumberFormatter().number(from: labelDisplay.text!)?.doubleValue)!
            }
            
            return test
            
        }
        set (newValue)
        {
            print("\(newValue) setval")
            
            if(newValue.isNormal){
                labelDisplay.text = "\(newValue)"
            }else{
                labelDisplay.text = "Error"
                
            }
            
            userHasStaredTyping = false
        }
    }
    
    @IBAction func enter() {
        
        //display the calculation on the displayvaile when entered is pressed
        //every time enterr is pressed the decimal key will be enabled
        // display the calculations on the calcdisplay
        userHasStaredTyping = false
        print("set3ß")
        self.calcEngine!.operandStack.append(displayValue)
        print("set2")
        decimal.isEnabled = true
        calcDisplay.text! += "\(displayValue)" + "↵"
        displayStr.append("\(displayValue) ↵ ")
        print ("Operand Stack on Engine = \(self.calcEngine!.operandStack)")
        decimal.isEnabled = true
        
    }
    
    @IBAction func operation(_ sender: UIButton) {
        
        let operation = sender.currentTitle!
        
        if userHasStaredTyping {
            enter()
            
        }
        
        self.displayValue = (self.calcEngine?.operate(operation: operation))!
        print("set1")
        calcDisplay.text! += "\(operation)"
        displayStr.append("\(operation) ")
        
        enter()
        
    }
    
    
    
    
    @IBAction func decimalKey(_ sender: UIButton) {
        let decimalkey = sender.currentTitle!
        if userHasStaredTyping{
            labelDisplay.text = labelDisplay.text! + "\(decimalkey)"
            decimal.isEnabled = false
            
        }
    }
    
    //    @IBAction func pointkey(_ sender: UIButton) {
    ////        labelDisplay.text = labelDisplay.text! + "."
    ////        calcDisplay.text = calcDisplay.text! + "\(".")"
    ////        sender.isEnabled = false
    //
    //
    //    }
    //
    
    
    
    
    
    @IBAction func segmentedcontrolARC(_ sender: UISegmentedControl) {
        // if statement
        // if arc is on change sin and setTitle to sin-1
        //else keep setTitle as sin
        if(sin.titleLabel!.text == "sin"){
            sin.setTitle("sin ⁻¹", for: UIControlState.normal)
        }
        else{
            sin.setTitle("sin", for: UIControlState.normal)
        }
        // if arc is on change sin and setTitle to cos-1
        //else keep setTitle as cos
        if (cos.titleLabel!.text == "cos"){
            cos.setTitle("cos ⁻¹", for: UIControlState.normal)
        }
        else{
            cos.setTitle("cos", for: UIControlState.normal)
        }
        // if arc is on change sin and setTitle to tan-1
        //else keep setTitle as tan
        if (tan.titleLabel!.text == "tan"){
            tan.setTitle("tan ⁻¹", for: UIControlState.normal)
        }
        else{
            tan.setTitle("tan", for: UIControlState.normal)
        }
        
        
    }
    
    @IBAction func CclearKey(_ sender: UIButton) {
        //removes digti in label back to zero
        labelDisplay.text = "0"
        //removes last element of the stack
        self.calcEngine!.operandStack.removeLast()
        userHasStaredTyping = false
        decimal.isEnabled = true
        
        //stop the clear key from crashing
        //
        if (self.calcEngine!.operandStack.count > 1){
            self.calcEngine!.operandStack.removeLast()
        }
    }
    
    
    @IBAction func allClearAC(_ sender: UIButton) {
        newStr.append("\(displayStr) \n")
        
        //removes all buffer entries and return labeldisplay as 0 and wipes out the calcdislplay
        //reenables the enter button
        labelDisplay.text = "0"
        calcDisplay.text = ("")
        self.calcEngine!.operandStack.removeAll()
        userHasStaredTyping = false
        decimal.isEnabled = true
        decimal.isEnabled = true
        
    }
    
    
    @IBAction func degRad(_ sender: UIButton) {
        // allows the user to switch between rad & deg
        // if the user clickes deg label will update to rad also the updatelabel will upate with the new text
        // dont enable the rad calculations in calcengine
        if(sender.titleLabel!.text == "deg"){
            updatelabel.text = "Rad"
            sender.setTitle("rad", for: UIControlState.normal)
            self.calcEngine!.deg = false
        }
        else{
            // if its is deg then set updatelabel as deg and enable the deg calculations in calcengine
            updatelabel.text = "Deg"
            sender.setTitle("deg", for: UIControlState.normal)
            self.calcEngine!.deg = true
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        //        let tapeViewController: tapeViewController = segue.destination as! tapeViewController
        //        tapeViewController.stringTape += calcDisplay.text!
        //returns a reference to an object capable of interacting with NSUserDefaults’s
        UserDefaults.standard.setValue(newStr, forKey: "calcDisplay")
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

