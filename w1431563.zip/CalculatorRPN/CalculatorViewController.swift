//
//  CalculatorViewController.swift
//  CalculatorRPN
//
//  Created by dharm on 21/02/2017.
//  Copyright © 2017 dharm. All rights reserved.
//

import Foundation
import UIKit

class CalculatorViewController: UIViewController {
    
    
    @IBOutlet weak var cleartape: UIButton!
    @IBOutlet weak var calcTape: UITextView!
    
    var getTape = Array<String>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for line in getTape{
            calcTape.text = calcTape.text + line + "\r\n"
        }
      
    }
    
    @IBAction func clearfunc(_ sender: UIButton) {
        calcTape.text = "";
    }
//    let defaults = UserDefaults.standard
//
//    let array_get = defaults.objectForKey("SavedArray") as? [String] ?? [String]()

    
}
