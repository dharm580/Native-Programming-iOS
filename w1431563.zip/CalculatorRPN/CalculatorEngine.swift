//
//  CalculatorEngine.swift
//  CalculatorRPN
//
//  Created by dharm on 07/02/2017.
//  Copyright © 2017 dharm. All rights reserved.
//

import Foundation
import UIKit

class CalculatorEngine:NSObject{
    var numberoverX = 0.0
    var srf = 0.0
    var xSquared = 0.0
    var operandStack = Array<Double>()
    var deg = true
    func updateStackWithValue(value: Double)
    {
        self.operandStack.append(value)
    }
    
    func logE(val: Double, forBase base: Double) -> Double{
        return log(val)/log(base)
    }
    
    func operate(operation: String) -> Double
    {
        switch operation
        {
        case "×":
            if operandStack.count >= 2
            {
                return self.operandStack.removeLast() * self.operandStack.removeLast()
            }
        case "÷":
            if operandStack.count >= 2
            {
                return self.operandStack.removeFirst() / self.operandStack.removeLast()
            }
        case "+":
            if operandStack.count >= 2
            {
                return self.operandStack.removeLast() + self.operandStack.removeLast()
            }
        case "−":
            if operandStack.count >= 2
            {
                return self.operandStack.removeFirst() - self.operandStack.removeLast()
            }
        case "sin":
            if operandStack.count >= 1
            {
                var s1 = self.operandStack.removeLast()
                if (deg == true){
                    s1 = s1 * (M_PI / 180)
                    return sin(s1)
                }
                else{
                    print ("RAD")
                    return sin(s1)
                }
            }
            
        case "cos":
            if operandStack.count >= 1
            {
                var c1 = self.operandStack.removeLast()
                if (deg == true){
                    c1 = c1 * (M_PI / 180)
                    return cos(c1)
                }else{
                    print ("RAD")
                    return cos(c1)
                }
            }
            
        case "tan":
            if operandStack.count >= 1
            {
                var t1 = self.operandStack.removeLast()
                if (deg == true){
                    t1 = t1 * (M_PI / 180)
                    return tan(t1)
                }
                else{
                    print ("RAD")
                    return tan(t1)
                }
                
            }
        case "√":
            if operandStack.count >= 1
            {
                srf = self.operandStack.removeLast()
                return sqrt(srf)
            }
            
        case "∏":
            return round (100000000 * M_PI) / 100000000
            
        case "x²":
            if operandStack.count >= 1{
                xSquared = self.operandStack.removeLast()
                return (xSquared * xSquared)
            }
            
        case "x⁻¹":
            if operandStack.count >= 1
            {
                numberoverX = self.operandStack.removeLast()
                return (1.0 / numberoverX)
            }
            
        case "±":
            return self.operandStack.removeLast() * (-1)
            
        case "log₁₀":
            if operandStack.count >= 1 {
                return log10(self.operandStack.removeLast())
            }
            
        case "logₑ":
            if operandStack.count >= 1 {
                let number1 = self.operandStack.removeLast()
                return logE(val: number1, forBase: M_E)
            }
        case "sin ⁻¹":
            if operandStack.count >= 1
            {
                var s1 = self.operandStack.removeLast()
                if (deg == true) {
                    s1 = asin(s1) * 180 / M_PI
                    
                    print("DEG")
                    return s1
                }
                else{
                    print ("RAD")
                    return asin(s1)
                }
            }
            
        case "cos ⁻¹":
            if operandStack.count >= 1
            {
                var c1 = self.operandStack.removeLast()
                if (deg == true){
                    c1 = acos(c1) * 180 / M_PI
                    print("DEG")
                    return c1
                }
                else{
                    print ("RAD")
                    return acos(c1)
                }
                
            }
        case "tan ⁻¹":
            if operandStack.count >= 1
            {
                var t1 = self.operandStack.removeLast()
                if (deg == true){
                    t1 = atan(t1) * 180 / M_PI
                    print ("DEG")
                    return t1
                }
                return atan(t1)
            }

        default:break
        }
        return 0.0
    }
}
