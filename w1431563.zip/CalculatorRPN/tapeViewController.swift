//
//  tapeViewController.swift
//  CalculatorRPN
//
//  Created by dharm on 27/02/2017.
//  Copyright © 2017 dharm. All rights reserved.
//

import UIKit

class tapeViewController: UIViewController {

    
    @IBOutlet weak var tapeViewText: UITextView!
    var stringTape: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        stringTape = UserDefaults.standard.object(forKey: "calcDisplay") as! String
        
        tapeViewText.text = "\(stringTape)"
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func clearTapeview(_ sender: UIButton) {
        UserDefaults.standard.removeObject(forKey: "calcDisplay")
        UserDefaults.standard.setValue("", forKey: "calcDisplay")
        tapeViewText.text! = ""
    }
    
    /*    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
